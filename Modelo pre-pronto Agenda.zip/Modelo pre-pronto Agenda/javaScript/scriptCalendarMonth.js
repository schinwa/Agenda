      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendarMonth');
        var calendar = new FullCalendar.Calendar(calendarEl, {
          initialView: 'dayGridMonth',
          locale: 'pt-BR',
          buttonText: {
            today: 'Hoje'
          },

          dateClick: function(info) { // Aqui é quando se clica em uma data
            if (info.view.type == "dayGridMonth") {
              calendar.changeView('timeGrid', info.dateStr);
            } else{
              var modal = document.getElementById("modalDateClick");
              
              var span = document.getElementsByClassName("close")[0];

            // When the user clicks the button, open the modal 
            onclick = function() {
            modal.style.display = "block";
            }

            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
            modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
            }
            }
          },

          eventClick: function(info) { // Aqui se trata de qaundo eu clico em um evento  
            alert('Event: ' + info.event.title);
            alert('Coordinates: ' + info.jsEvent.pageX + ',' + info.jsEvent.pageY);
            alert('View: ' + info.view.type);
            // change the border color just for fun  
            info.el.style.borderColor = 'red';
          },
          events: 'Aqui vai o caminho para o local onde selecionamos os dados, no caso onde estão os eventos'

        });
        calendar.render();
      });