<?php
    // Essa página coleta os dados trazidos pelo banco de dados
        // Após a coleta em formato Json ela os "exibe". Deixando no modelo pedido pelo calendário
    $objEvents = new displayEvents();
    echo $objEvents->getEvents();
?>